# -*- coding: utf-8 -*-
"""PhysicsLab8 Android: Kivy mobile educational lab, offline simulation."""
import math
import os
import sqlite3
import csv
import webbrowser
from datetime import datetime
from pathlib import Path
from functools import partial

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.graphics import Color, Line, Rectangle, Ellipse, RoundedRectangle
from kivy.metrics import dp
from kivy.properties import NumericProperty, StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.dropdown import DropDown
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.uix.slider import Slider
from kivy.uix.textinput import TextInput

GREEN = (0.08, .42, .23, 1)
LIGHT = (.91, .97, .92, 1)
WHITE = (1, 1, 1, 1)
DARK = (.10, .22, .15, 1)
BLUE = (.12, .38, .75, 1)

LABS = [
 ('Смешивание воды', 'Сравнение количеств теплоты при смешивании воды разной температуры', 'Два сосуда, калориметр, термометры, вода', 'Q = c·m·Δt; Qотд = Qпол (без потерь)', 'Измерьте массы и начальные температуры; найдите равновесную температуру.'),
 ('Плавление льда', 'Определение удельной теплоты плавления льда', 'Лёд, калориметр, тёплая вода, весы, термометр', 'Q = λ·m; Q = c·m·Δt; λ ≈ 334 000 Дж/кг', 'Измените массу льда и температуру воды; наблюдайте тепловой баланс.'),
 ('Электрическая цепь', 'Сборка электрической цепи и измерение силы тока и напряжения', 'Источник, ключ, амперметр, вольтметр, резистор', 'I = U/R; U = I·R', 'Соберите цепь: амперметр последовательно, вольтметр параллельно резистору.'),
 ('Закон Ома', 'Исследование зависимости силы тока от напряжения', 'Источник, ключ, амперметр, вольтметр, резистор', 'I = U/R; R = U/I', 'Соберите цепь и изменяйте напряжение при постоянном сопротивлении.'),
 ('Соединения', 'Последовательное и параллельное соединение проводников', 'Источник, ключ, два резистора, амперметр, вольтметр', 'Rпосл = R₁ + R₂; Rпар = R₁·R₂/(R₁+R₂)', 'Соберите сначала последовательную, затем параллельную схему.'),
 ('Работа и мощность', 'Определение работы и мощности электрического тока', 'Источник, ключ, резистор, амперметр, вольтметр, секундомер', 'P = U·I; A = U·I·t', 'Соберите цепь; измените время, напряжение и сопротивление.'),
 ('Собирающая линза', 'Определение фокусного расстояния собирающей линзы', 'Линза, предмет, экран, линейка', '1/F = 1/a + 1/b; D = 1/F (F в м)', 'Меняйте расстояние до предмета и фокусное расстояние; найдите положение изображения.')
]
VIDEOS = [
 'https://www.youtube.com/watch?v=vcH29Zwrj4s',
 'https://www.youtube.com/results?search_query=удельная+теплота+плавления+льда+лабораторная+8+класс',
 'https://www.youtube.com/watch?v=n3GGAD48C_I',
 'https://www.youtube.com/watch?v=pajCFKc9Cg0',
 'https://www.youtube.com/watch?v=YBg3r6rbNGQ',
 'https://www.youtube.com/results?search_query=работа+и+мощность+электрического+тока+опыт',
 'https://www.youtube.com/watch?v=Iw3g9A4qJD0'
]
STEPS = [
 ['Выберите массы холодной и горячей воды.', 'Установите начальные температуры.', 'Нажмите «Запустить опыт».', 'Запишите t конечную и сравните количества теплоты.'],
 ['Выберите массу тёплой воды и льда.', 'Укажите начальную температуру воды.', 'Запустите плавление.', 'Рассчитайте тепловой баланс и λ.'],
 ['Изучите условную схему.', 'Нажмите два контакта для соединения.', 'Проверьте схему и замкните ключ.', 'Измерьте I и U.'],
 ['Соберите схему по образцу.', 'Проверьте соединения.', 'Меняйте U при неизменном R.', 'Запишите пары U и I.'],
 ['Выберите тип соединения.', 'Соберите цепь по схеме.', 'Проверьте соединения.', 'Сравните R и I для двух схем.'],
 ['Соберите электрическую цепь.', 'Проверьте схему и замкните ключ.', 'Установите время.', 'Вычислите P и A.'],
 ['Установите фокусное расстояние.', 'Установите расстояние до предмета.', 'Наблюдайте ход лучей.', 'Вычислите оптическую силу.']
]

def lbl(text, size=15, color=DARK, height=None, bold=False):
    x = Label(text=str(text), font_size=dp(size), color=color, bold=bold,
              size_hint_y=None, halign='left', valign='middle')
    x.bind(width=lambda obj, val: setattr(obj, 'text_size', (max(10,val-dp(8)),None)))
    x.bind(texture_size=lambda obj, val: setattr(obj,'height', max(dp(height or 24), val[1]+dp(10))))
    x.height=dp(height or 34)
    return x

def btn(text, callback, color=GREEN, h=46):
    b=Button(text=text, size_hint_y=None, height=dp(h), background_normal='',
             background_color=color, color=WHITE, font_size=dp(15), bold=True)
    b.bind(on_release=callback)
    return b

class ExperimentCanvas(BoxLayout):
    """Canvas draws physical apparatus; touch selects terminal on electric experiments."""
    progress=NumericProperty(0)
    def __init__(self, owner, **kw):
        super().__init__(**kw)
        self.owner=owner
        self.bind(pos=lambda *_:self.draw(), size=lambda *_:self.draw(), progress=lambda *_:self.draw())
        self.contacts={}
    def draw(self):
        self.canvas.clear()
        x,y=self.pos; w,h=self.size
        if w<=0 or h<=0:return
        with self.canvas:
            Color(*WHITE); RoundedRectangle(pos=(x+dp(2),y+dp(2)),size=(w-dp(4),h-dp(4)),radius=[dp(12)])
            Color(.80,.90,.82,1); Line(rounded_rectangle=(x+dp(2),y+dp(2),w-dp(4),h-dp(4),dp(12)),width=1.2)
        lab=self.owner.lab
        if lab in (0,1):self.thermal(x,y,w,h)
        elif lab in (2,3,4,5):self.circuit(x,y,w,h)
        else:self.optics(x,y,w,h)
    def thermal(self,x,y,w,h):
        p=self.progress
        for i in range(2):
            cx=x+w*(.31 if i==0 else .69); bottom=y+h*.2
            with self.canvas:
                Color(.18,.45,.65,.8) if i==0 else Color(.90,.43,.18,.8)
                Rectangle(pos=(cx-w*.12,bottom),size=(w*.24,h*(.34+(.08*p if i==1 else 0))))
                Color(.12,.32,.32,1); Line(points=[cx-w*.12,bottom+h*.52,cx-w*.12,bottom,cx+w*.12,bottom,cx+w*.12,bottom+h*.52],width=dp(3))
                Color(.9,.93,.96,1); Rectangle(pos=(cx+w*.14,bottom),size=(dp(10),h*.52))
                Color(.85,.12,.12,1); Rectangle(pos=(cx+w*.14,bottom),size=(dp(10),h*(.13+.31*(p if i==0 else 1-p))))
        if self.owner.lab==1:
            with self.canvas:
                Color(.77,.92,1,1); Rectangle(pos=(x+w*.57,y+h*(.34+p*.08)),size=(w*.10*(1-p*.85),w*.09*(1-p*.85)))
    def circuit(self,x,y,w,h):
        nodes=self.owner.nodes
        if not nodes:return
        self.contacts={}
        for name,(fx,fy) in nodes.items():
            cx=x+fx*w; cy=y+fy*h
            self.contacts[name]=(cx,cy)
        # wires (all endpoints are visible)
        with self.canvas:
            Color(.10,.42,.21,1)
            for a,b in self.owner.wires:
                if a in self.contacts and b in self.contacts:
                    Line(points=[*self.contacts[a],*self.contacts[b]],width=dp(2.7))
        # schematic reference rendered in upper-right inset
        self.draw_schematic(x+w*.53,y+h*.55,w*.43,h*.4)
        for name,(cx,cy) in self.contacts.items():
            with self.canvas:
                Color(.96,.97,.96,1); Ellipse(pos=(cx-dp(22),cy-dp(22)),size=(dp(44),dp(44)))
                Color(*BLUE if name==self.owner.selected else DARK)
                Line(circle=(cx,cy,dp(21)),width=dp(2))
                Color(.98,.72,.12,1); Ellipse(pos=(cx-dp(5),cy-dp(5)),size=(dp(10),dp(10)))
            # Labels are painted via core text
            from kivy.core.text import Label as CoreLabel
            text=CoreLabel(text=name, font_size=dp(12), color=DARK)
            text.refresh()
            with self.canvas:
                Color(*DARK); Rectangle(texture=text.texture,pos=(cx-text.texture.size[0]/2,cy-dp(39)),size=text.texture.size)
        if self.owner.power_on and self.owner.circuit_valid():
            with self.canvas:
                Color(.10,.75,.25,.8); Line(circle=(x+w*.50,y+h*.25,dp(15)+dp(4)*self.progress),width=dp(3))
    def draw_schematic(self,x,y,w,h):
        """Symbolic reference: source, switch, ammeter, resistor, voltmeter branch."""
        with self.canvas:
            Color(.94,.98,.95,1); RoundedRectangle(pos=(x,y),size=(w,h),radius=[dp(8)])
            Color(.15,.24,.18,1)
            xa=x+w*.10; xb=x+w*.87; ya=y+h*.25; yb=y+h*.78
            Line(points=[xa,ya,xa,yb,xb,yb,xb,ya,xa,ya],width=1.7)
            # battery
            Line(points=[xa-dp(9),ya+h*.08,xa+dp(9),ya+h*.08],width=2)
            Line(points=[xa-dp(5),ya+h*.01,xa+dp(5),ya+h*.01],width=2)
            # switch
            Line(points=[x+w*.30,yb,x+w*.37,yb+dp(10)],width=2)
            # ammeter
            Line(circle=(x+w*.60,yb,dp(11)),width=1.8)
            # resistor
            Rectangle(pos=(x+w*.41,ya-dp(7)),size=(w*.18,dp(14)))
            # voltmeter parallel branch
            Line(points=[x+w*.40,ya,x+w*.40,y+h*.49,x+w*.75,y+h*.49,x+w*.75,ya],width=1.3)
            Line(circle=(x+w*.58,y+h*.49,dp(11)),width=1.7)
        from kivy.core.text import Label as CoreLabel
        for txt,cx,cy in [('A',x+w*.60,yb),('V',x+w*.58,y+h*.49),('R',x+w*.50,ya)]:
            t=CoreLabel(text=txt,font_size=dp(12),color=DARK);t.refresh()
            with self.canvas:
                Color(*DARK); Rectangle(texture=t.texture,pos=(cx-t.texture.size[0]/2,cy-t.texture.size[1]/2),size=t.texture.size)
    def optics(self,x,y,w,h):
        f=max(.1,self.owner.values.get('F',20)); a=max(1,self.owner.values.get('a',60))
        lx=x+w*.54; ly=y+h*.5; scale=min(w/140,dp(3))
        with self.canvas:
            Color(.25,.35,.25,1); Line(points=[x+w*.05,ly,x+w*.95,ly],width=1.4)
            Color(.12,.48,.78,1); Line(ellipse=(lx-dp(12),y+h*.16,dp(24),h*.68),width=dp(3))
            ox=max(x+w*.08,lx-a*scale)
            Color(.7,.18,.12,1); Line(points=[ox,ly,ox,ly+h*.23],width=dp(4))
            if a>f:
                b=f*a/(a-f); ix=min(x+w*.95,lx+b*scale)
                Color(.10,.55,.25,1); Line(points=[ix,ly,ix,ly-h*.23*b/a],width=dp(3))
                Color(.90,.5,.1,1); Line(points=[ox,ly+h*.23,lx,ly+h*.23,ix,ly-h*.23*b/a],width=1.6)
                Line(points=[ox,ly+h*.23,lx,ly,ix,ly-h*.23*b/a],width=1.6)
    def on_touch_down(self,touch):
        if self.owner.lab in (2,3,4,5) and self.collide_point(*touch.pos):
            for name,(cx,cy) in self.contacts.items():
                if (touch.x-cx)**2+(touch.y-cy)**2<dp(30)**2:
                    self.owner.select_contact(name);return True
        return super().on_touch_down(touch)

class LabApp(App):
    def build(self):
        self.title='Физическая лаборатория — 8 класс'
        self.user_data_dir=App.get_running_app().user_data_dir
        os.makedirs(self.user_data_dir,exist_ok=True)
        self.db=Path(self.user_data_dir)/'lab8.sqlite3'
        with sqlite3.connect(self.db) as con:
            con.execute('CREATE TABLE IF NOT EXISTS measurements (id INTEGER PRIMARY KEY, created TEXT, pupil TEXT, school_class TEXT, lab INTEGER, parameters TEXT, result TEXT, calculation TEXT, conclusion TEXT)')
        self.lab=0;self.step=0;self.progress=0;self.values={};self.wires=set();self.selected=None;self.power_on=False
        self.name='';self.school_class='8';self.calculation='';self.conclusion='';self.records=[]
        self.root=BoxLayout(orientation='vertical',spacing=dp(4),padding=dp(6))
        Window.clearcolor=LIGHT
        self.top=lbl('ФИЗИКА • 8 КЛАСС   |   Q=cmΔt  •  I=U/R  •  P=UI',16,GREEN,45,True)
        self.root.add_widget(self.top)
        self.nav=BoxLayout(size_hint_y=None,height=dp(46),spacing=dp(4))
        for label,func in [('Опыты',self.show_experiment),('Тетрадь',self.show_notebook),('Результаты',self.show_results)]:
            self.nav.add_widget(btn(label,lambda _b,f=func:f(),h=44))
        self.root.add_widget(self.nav)
        self.body=BoxLayout(orientation='vertical')
        self.root.add_widget(self.body)
        self.choose_lab(0)
        return self.root
    def clear(self):
        self.body.clear_widgets()
    def scroll(self):
        scroll=ScrollView(do_scroll_x=False)
        col=BoxLayout(orientation='vertical',size_hint_y=None,spacing=dp(7),padding=dp(6))
        col.bind(minimum_height=col.setter('height'))
        scroll.add_widget(col);self.body.add_widget(scroll)
        return col
    def popup(self,title,message):
        content=BoxLayout(orientation='vertical',padding=dp(12),spacing=dp(8))
        content.add_widget(lbl(message,15,height=90))
        p=Popup(title=title,content=content,size_hint=(.92,.45))
        content.add_widget(btn('Понятно',lambda *_:p.dismiss()))
        p.open()
    def choose_lab(self,index):
        self.lab=index;self.step=0;self.progress=0;self.power_on=False;self.selected=None;self.wires=set()
        self.values={'cold_m':200,'hot_m':150,'cold_t':20,'hot_t':75,'water_m':250,'ice_m':40,'water_t':50,'U':6,'R':12,'R1':10,'R2':20,'time':30,'F':20,'a':60,'parallel':0}
        self.show_experiment()
    def lab_selector(self,col):
        d=DropDown(auto_width=False)
        for i,item in enumerate(LABS):
            b=Button(text=f'{i+1}. {item[0]}',size_hint_y=None,height=dp(52),font_size=dp(14))
            b.bind(on_release=lambda _b,n=i:(d.dismiss(),self.choose_lab(n)))
            d.add_widget(b)
        choose=btn(f'Лабораторная №{self.lab+1}: {LABS[self.lab][0]}  ▾',lambda b:d.open(b),h=55)
        col.add_widget(choose)
    def show_experiment(self):
        self.clear(); col=self.scroll();self.lab_selector(col)
        col.add_widget(lbl(LABS[self.lab][1],17,GREEN,58,True))
        col.add_widget(lbl('Цель: '+LABS[self.lab][4],14,height=52))
        col.add_widget(lbl('Оборудование: '+LABS[self.lab][2],13,height=50))
        col.add_widget(lbl('Шаг '+str(self.step+1)+' из 4: '+STEPS[self.lab][self.step],14,BLUE,62,True))
        hints=BoxLayout(size_hint_y=None,height=dp(44),spacing=dp(6))
        hints.add_widget(btn('◀ Назад',lambda *_:self.move_step(-1)))
        hints.add_widget(btn('Подсказка',lambda *_:self.popup('Подсказка',STEPS[self.lab][self.step]),BLUE))
        hints.add_widget(btn('Далее ▶',lambda *_:self.move_step(1)))
        col.add_widget(hints)
        self.model=ExperimentCanvas(self,size_hint_y=None,height=dp(265))
        self.model.progress=self.progress
        col.add_widget(self.model)
        if self.lab in (2,3,4,5):
            col.add_widget(lbl('Схема (в правом верхнем углу) — образец. Нажмите два кружка-контакта по очереди, чтобы провести провод.',13,height=65))
            row=BoxLayout(size_hint_y=None,height=dp(45),spacing=dp(4))
            row.add_widget(btn('Следующий провод',lambda *_:self.next_wire()))
            row.add_widget(btn('Собрать с подсказками',lambda *_:self.auto_wire(),BLUE))
            col.add_widget(row)
            row2=BoxLayout(size_hint_y=None,height=dp(45),spacing=dp(4))
            row2.add_widget(btn('Проверить схему',lambda *_:self.check_circuit()))
            row2.add_widget(btn('Очистить провода',lambda *_:self.clear_wires(),BLUE))
            col.add_widget(row2)
        col.add_widget(lbl('Настройки эксперимента',16,GREEN,34,True))
        self.make_sliders(col)
        col.add_widget(btn('▶ Запустить опыт / снять показания',lambda *_:self.run_experiment(),h=52))
        self.result_label=lbl('Результат появится после запуска.',14,height=75)
        col.add_widget(self.result_label)
        col.add_widget(btn('▶ Смотреть опыт на YouTube (интернет)',lambda *_:webbrowser.open(VIDEOS[self.lab]),BLUE))
        col.add_widget(btn('Перейти в тетрадь →',lambda *_:self.show_notebook()))
        Clock.schedule_once(lambda *_:self.model.draw(),0)
    @property
    def nodes(self):
        if self.lab==4:
            return {'+':(.12,.25),'К':(.25,.7),'A':(.46,.7),'R1':(.73,.42),'R2':(.75,.23),'-':(.13,.48),'V':(.42,.23)}
        return {'+':(.12,.25),'К':(.26,.72),'A':(.47,.72),'R':(.75,.42),'-':(.12,.50),'V':(.46,.24)}
    def required_edges(self):
        if self.lab==4:
            return [('+','К'),('К','A'),('A','R1'),('R1','R2'),('R2','-'),('V','R1'),('V','R2')]
        return [('+','К'),('К','A'),('A','R'),('R','-'),('V','R'),('V','-')]
    def edge(self,a,b):return tuple(sorted((a,b)))
    def circuit_valid(self):return {self.edge(*p) for p in self.required_edges()}==self.wires
    def select_contact(self,name):
        if self.selected is None:
            self.selected=name;self.popup('Первый контакт',f'Выбран контакт {name}. Теперь коснитесь второго контакта.')
        elif name==self.selected:self.selected=None
        else:
            edge=self.edge(self.selected,name)
            if edge in self.wires:self.wires.remove(edge)
            else:self.wires.add(edge)
            self.selected=None
        self.model.draw()
    def next_wire(self):
        for a,b in self.required_edges():
            edge=self.edge(a,b)
            if edge not in self.wires:
                self.wires.add(edge);self.model.draw()
                self.popup('Соединение добавлено',f'Провод: {a} → {b}. Посмотрите на рабочее поле.')
                return
        self.popup('Схема собрана','Все соединения по образцу добавлены. Нажмите «Проверить схему».')
    def auto_wire(self):
        self.wires={self.edge(*e) for e in self.required_edges()};self.model.draw()
        self.popup('Обучающий режим','Провода добавлены по образцу. Для самостоятельной практики нажмите «Очистить провода».')
    def clear_wires(self):self.wires.clear();self.power_on=False;self.model.draw()
    def check_circuit(self):
        if self.circuit_valid():self.popup('Схема верна','Все соединения совпадают с образцом. Можно запустить опыт.')
        else:
            missing=[f'{a}–{b}' for a,b in self.required_edges() if self.edge(a,b) not in self.wires]
            extra=len(self.wires-{self.edge(*e) for e in self.required_edges()})
            self.popup('Подсказка по схеме','Нужно соединить: '+(', '.join(missing[:4]) or 'все нужные соединения есть')+(f'. Лишних проводов: {extra}.' if extra else '.'))
    def move_step(self,n):
        self.step=max(0,min(3,self.step+n));self.show_experiment()
    def slider(self,col,title,key,minimum,maximum,step,unit):
        line=BoxLayout(size_hint_y=None,height=dp(54),spacing=dp(5))
        value=lbl('',13,height=40)
        def update(_obj,v):
            v=round(round(v/step)*step,3);self.values[key]=v
            value.text=f'{title}: {v:g} {unit}'
            if hasattr(self,'model'):self.model.draw()
        s=Slider(min=minimum,max=maximum,value=self.values[key],step=step)
        s.bind(value=update);update(s,self.values[key]);line.add_widget(value);line.add_widget(s)
        col.add_widget(line)
    def make_sliders(self,col):
        if self.lab==0:
            for p in [('Масса холодной воды','cold_m',50,500,10,'г'),('Масса горячей воды','hot_m',50,500,10,'г'),('Температура холодной','cold_t',5,40,1,'°C'),('Температура горячей','hot_t',45,95,1,'°C')]:self.slider(col,*p)
        elif self.lab==1:
            for p in [('Масса воды','water_m',100,600,10,'г'),('Масса льда','ice_m',10,150,5,'г'),('Температура воды','water_t',20,90,1,'°C')]:self.slider(col,*p)
        elif self.lab in (2,3,5):
            for p in [('Напряжение','U',1,12,.5,'В'),('Сопротивление','R',2,40,1,'Ом')]:self.slider(col,*p)
            if self.lab==5:self.slider(col,'Время','time',5,120,5,'с')
        elif self.lab==4:
            for p in [('Напряжение','U',1,12,.5,'В'),('R1','R1',2,40,1,'Ом'),('R2','R2',2,40,1,'Ом')]:self.slider(col,*p)
            col.add_widget(btn('Тип: '+('параллельно' if self.values['parallel'] else 'последовательно')+' (нажать для смены)',lambda b:self.toggle_connection(b),BLUE))
        else:
            self.slider(col,'Фокусное расстояние','F',5,35,1,'см');self.slider(col,'Расстояние до предмета','a',10,100,1,'см')
    def toggle_connection(self,b):
        self.values['parallel']=1-self.values['parallel'];b.text='Тип: '+('параллельно' if self.values['parallel'] else 'последовательно')
    def calculate(self):
        v=self.values
        if self.lab==0:
            m1=v['cold_m']/1000;m2=v['hot_m']/1000;t=(m1*v['cold_t']+m2*v['hot_t'])/(m1+m2)
            q=4200*m1*(t-v['cold_t']);return f't = {t:.2f} °C; Qпол ≈ Qотд = {q:.1f} Дж'
        if self.lab==1:
            mw=v['water_m']/1000;mi=v['ice_m']/1000; available=4200*mw*v['water_t'];needed=334000*mi
            if available<needed:return f'Лёд растаял не полностью: приблизительно {available/334000*1000:.1f} г из {v["ice_m"]:g} г. t ≈ 0 °C'
            t=(available-needed)/(4200*(mw+mi));return f'Лёд растаял; t ≈ {t:.2f} °C; λ = 334000 Дж/кг (параметр модели)'
        if self.lab in (2,3):return f'U = {v["U"]:g} В; R = {v["R"]:g} Ом; I = {v["U"]/v["R"]:.3f} А'
        if self.lab==4:
            r=(v['R1']*v['R2']/(v['R1']+v['R2'])) if v['parallel'] else v['R1']+v['R2']
            return f'Rэкв = {r:.2f} Ом; I = {v["U"]/r:.3f} А; соединение: '+('параллельное' if v['parallel'] else 'последовательное')
        if self.lab==5:
            i=v['U']/v['R'];return f'I = {i:.3f} А; P = {v["U"]*i:.2f} Вт; A = {v["U"]*i*v["time"]:.2f} Дж'
        if v['a']<=v['F']:return 'При a ≤ F действительное изображение на экране не получается.'
        b=v['a']*v['F']/(v['a']-v['F']);return f'b = {b:.2f} см; D = {100/v["F"]:.2f} дптр'
    def run_experiment(self):
        if self.lab in (2,3,4,5) and not self.circuit_valid():
            self.check_circuit();return
        self.power_on=True;self.progress=0
        self.last_result=self.calculate()
        self.result_label.text=self.last_result
        def tick(_dt):
            self.progress=min(1,self.progress+.04)
            self.model.progress=self.progress
            if self.progress>=1:return False
        Clock.schedule_interval(tick,.06)
        self.records.append((datetime.now().strftime('%H:%M:%S'),dict(self.values),self.last_result))
    def show_notebook(self):
        self.clear();col=self.scroll()
        col.add_widget(lbl('ИНТЕРАКТИВНАЯ ТЕТРАДЬ',19,GREEN,42,True))
        col.add_widget(lbl('Лабораторная №'+str(self.lab+1)+': '+LABS[self.lab][1],15,height=65))
        col.add_widget(lbl('Фамилия и имя ученика',14))
        self.pupil_input=TextInput(text=self.name,multiline=False,size_hint_y=None,height=dp(48),font_size=dp(17))
        col.add_widget(self.pupil_input)
        col.add_widget(lbl('Класс',14))
        self.class_input=TextInput(text=self.school_class,multiline=False,size_hint_y=None,height=dp(48),font_size=dp(17))
        col.add_widget(self.class_input)
        col.add_widget(lbl('Цель: '+LABS[self.lab][4],14,height=65))
        col.add_widget(lbl('Оборудование: '+LABS[self.lab][2],14,height=65))
        col.add_widget(lbl('ПОДСКАЗКА — ФОРМУЛЫ',15,GREEN,35,True))
        col.add_widget(lbl(LABS[self.lab][3],16,BLUE,80,True))
        col.add_widget(lbl('Измерения (записываются после запуска опыта)',14,height=40))
        col.add_widget(lbl('\n'.join(f'{t}: {r}' for t,_,r in self.records[-5:]) or 'Пока нет измерений',13,height=90))
        col.add_widget(lbl('Расчёты ученика',14))
        self.calc_input=TextInput(text=self.calculation,multiline=True,size_hint_y=None,height=dp(110),font_size=dp(16),hint_text='Запишите формулу, подстановку и ответ')
        col.add_widget(self.calc_input)
        col.add_widget(lbl('Вывод',14))
        self.concl_input=TextInput(text=self.conclusion,multiline=True,size_hint_y=None,height=dp(110),font_size=dp(16),hint_text='Что удалось установить?')
        col.add_widget(self.concl_input)
        col.add_widget(btn('Проверить расчёт (ориентир)',lambda *_:self.check_calculation(),BLUE))
        col.add_widget(btn('Сохранить тетрадь и результаты',lambda *_:self.save_notebook()))
    def check_calculation(self):
        self.calculation=self.calc_input.text
        self.popup('Проверка расчёта','Результат модели: '+self.calculate()+'\nСравните с собственной подстановкой. Проверка носит справочный характер.')
    def save_notebook(self):
        self.name=self.pupil_input.text.strip();self.school_class=self.class_input.text.strip()
        self.calculation=self.calc_input.text.strip();self.conclusion=self.concl_input.text.strip()
        if not self.name or not self.school_class:
            self.popup('Нужны данные','Введите фамилию, имя и класс.');return
        with sqlite3.connect(self.db) as con:
            con.execute('INSERT INTO measurements(created,pupil,school_class,lab,parameters,result,calculation,conclusion) VALUES (?,?,?,?,?,?,?,?)',
                        (datetime.now().isoformat(timespec='seconds'),self.name,self.school_class,self.lab+1,str(self.values),self.calculate(),self.calculation,self.conclusion))
        self.popup('Сохранено','Работа сохранена в локальной базе устройства. Её можно найти во вкладке «Результаты».')
    def show_results(self):
        self.clear();col=self.scroll();col.add_widget(lbl('СОХРАНЁННЫЕ РАБОТЫ',18,GREEN,48,True))
        with sqlite3.connect(self.db) as con:
            rows=con.execute('SELECT created,pupil,school_class,lab,result FROM measurements ORDER BY id DESC LIMIT 60').fetchall()
        for created,pupil,cl,lab,result in rows:
            col.add_widget(lbl(f'{created} | {pupil} | {cl} класс | №{lab}\n{result}',13,height=75))
        col.add_widget(btn('Экспорт CSV',lambda *_:self.export_csv()))
        col.add_widget(lbl('Экспорт сохраняется в приватной папке приложения. Для передачи файла используйте файловый менеджер или механизм общего доступа устройства.',12,height=80))
    def export_csv(self):
        target=Path(self.user_data_dir)/'physics_lab8_export.csv'
        with sqlite3.connect(self.db) as con:
            rows=con.execute('SELECT created,pupil,school_class,lab,parameters,result,calculation,conclusion FROM measurements').fetchall()
        with open(target,'w',encoding='utf-8-sig',newline='') as f:
            w=csv.writer(f,delimiter=';');w.writerow(['Дата','Ученик','Класс','Лабораторная','Параметры','Результат','Расчёт','Вывод']);w.writerows(rows)
        self.popup('CSV создан',f'Файл сохранён:\n{target}\nДля удобной передачи потребуется функция «Поделиться» в следующей версии.')

if __name__=='__main__':
    LabApp().run()
