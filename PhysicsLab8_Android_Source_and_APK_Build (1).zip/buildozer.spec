[app]
title = Виртуальная физическая лаборатория 8
package.name = physicslab8
package.domain = org.schoolphysics
source.dir = .
source.include_exts = py,png,jpg,kv,txt,json
version = 1.0.0
requirements = python3,kivy
orientation = portrait
fullscreen = 0
android.permissions = INTERNET
android.api = 35
android.minapi = 24
android.archs = arm64-v8a
p4a.bootstrap = sdl2
[buildozer]
log_level = 2
warn_on_root = 1
